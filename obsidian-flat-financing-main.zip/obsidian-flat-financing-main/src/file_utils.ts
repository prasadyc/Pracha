import { App, TFile, Notice } from "obsidian";

export class FileUtils {
    constructor(private app: App) { }

    async ensureFileExists(path: string): Promise<boolean> {
        const file = this.app.vault.getAbstractFileByPath(path);
        if (file) {
            if (file instanceof TFile) return true;
            new Notice(`Path exists but is not a file: ${path}`);
            return false;
        }

        // File does not exist, create it
        try {
            await this.app.vault.create(path, "; Created by Obsidian Flat Financing Plugin\n");
            new Notice(`Created new Beancount file at: ${path}`);
            return true;
        } catch (error) {
            console.error(`Error creating file at ${path}:`, error);
            new Notice(`Failed to create Beancount file at ${path}`);
            return false;
        }
    }

    async appendToBeancountFile(path: string, content: string): Promise<boolean> {
        if (!await this.ensureFileExists(path)) return false;

        const file = this.app.vault.getAbstractFileByPath(path);
        if (!(file instanceof TFile)) return false;

        try {
            await this.app.vault.append(file, "\n" + content);
            return true;
        } catch (error) {
            console.error("Error appending to beancount file:", error);
            new Notice("Error appending to beancount file. Check console for details.");
            return false;
        }
    }

    async prependAccountToBeancountFile(path: string, content: string): Promise<boolean> {
        if (!await this.ensureFileExists(path)) return false;

        const file = this.app.vault.getAbstractFileByPath(path);
        if (!(file instanceof TFile)) return false;

        try {
            const currentContent = await this.app.vault.read(file);
            const lines = currentContent.split('\n');
            let insertIndex = 0;
            if (lines.length > 0 && lines[0].startsWith("; Created")) {
                insertIndex = 1;
            }
            lines.splice(insertIndex, 0, content, "");
            await this.app.vault.modify(file, lines.join('\n'));
            return true;
        } catch (error) {
            console.error("Error prepending to beancount file:", error);
            new Notice("Error saving account to beancount file. Check console for details.");
            return false;
        }
    }

    async replaceTransactionBlock(path: string, startLine: number, endLine: number, newContent: string): Promise<boolean> {
        if (!await this.ensureFileExists(path)) return false;
        const file = this.app.vault.getAbstractFileByPath(path);
        if (!(file instanceof TFile)) return false;

        try {
            const currentContent = await this.app.vault.read(file);
            const lines = currentContent.split('\n');
            const newLines = newContent.split('\n');
            lines.splice(startLine, endLine - startLine + 1, ...newLines);
            await this.app.vault.modify(file, lines.join("\n"));
            return true;
        } catch (e) {
            console.error("Error updating transaction block", e);
            new Notice("Error updating transaction. Check console.");
            return false;
        }
    }

    async deleteTransactionBlock(path: string, startLine: number, endLine: number): Promise<boolean> {
        if (!await this.ensureFileExists(path)) return false;
        const file = this.app.vault.getAbstractFileByPath(path);
        if (!(file instanceof TFile)) return false;

        try {
            const currentContent = await this.app.vault.read(file);
            const lines = currentContent.split('\n');
            // Remove the lines corresponding to the transaction block
            lines.splice(startLine, endLine - startLine + 1);
            await this.app.vault.modify(file, lines.join("\n"));
            return true;
        } catch (e) {
            console.error("Error deleting transaction block", e);
            new Notice("Error deleting transaction. Check console.");
            return false;
        }
    }

    async getBeanCountFile(path: string): Promise<TFile | null> {
        if (!await this.ensureFileExists(path)) return null;

        const file = this.app.vault.getAbstractFileByPath(path);
        return file instanceof TFile ? file : null;
    }

    async getFileContent(path: string): Promise<string> {
        const file = await this.getBeanCountFile(path);
        if (file) {
            return await this.app.vault.read(file);
        }
        return "";
    }

    async getAccounts(path: string): Promise<string[]> {
        // ensure existence so we don't get errors on empty fresh install
        await this.ensureFileExists(path);

        const content = await this.getFileContent(path);
        const accounts = new Set<string>();
        const lines = content.split("\n");

        for (const line of lines) {
            // Match "YYYY-MM-DD open Account:Name ..."
            // Allow for hyphens, underscores in account names
            // Remove ^ anchor to allow for indentation
            const openMatch = line.match(/\d{4}-\d{2}-\d{2}\s+open\s+([A-Za-z0-9\-_:]+)/);
            if (openMatch && openMatch[1]) {
                accounts.add(openMatch[1]);
            }
        }

        return Array.from(accounts).sort();
    }
}

